// $Id;

CONTENTS
---------
 * Introduction
 * Installation
 * Custom themes

Introduction
------------
This module will display blocks in a accordion widget. 
It will apply accordion widget for sidebar_first(left), sidebar_right(right) regions


Installation
------------
The drupal7 is having jquery 1.3.2 version and jquery UI is also available with the drupal core.
Install accordion_blocks module and enable.

Clear your cache, then block on left side and right side(if you have blocks both sides) will appear in accordion widget.

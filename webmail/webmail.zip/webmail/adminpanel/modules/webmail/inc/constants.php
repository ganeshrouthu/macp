<?php

/*
 * Copyright (C) 2002-2012 AfterLogic Corp. (www.afterlogic.com)
 * Distributed under the terms of the license described in COPYING
 *
 */

	define('WM_MODE_LOGGING', 'logging');
	define('WM_MODE_DAV', 'dav');
	define('WM_SWITCHER_MODE_NEW_DOMAIN', 'newdomain');
	define('WM_SWITCHER_MODE_EDIT_DOMAIN_GENERAL', 'editgeneral');
	define('WM_SWITCHER_MODE_EDIT_DOMAIN_WEBMAIL', 'editwebmail');
	define('WM_SWITCHER_MODE_EDIT_DOMAIN_ADDRESS_BOOK', 'editaddressbook');

	define('WM_SWITCHER_MODE_EDIT_USERS_GENERAL', 'editgeneral');

	/* langs */

	define('WM_MODE_DAV_NAME', 'Mobile sync');
	define('WM_MODE_LOGGING_NAME', 'Logging');
	define('WM_SWITCHER_MODE_NEW_DOMAIN_NAME', 'New domain');
	define('WM_SWITCHER_MODE_EDIT_DOMAIN_GENERAL_NAME', 'General');
	define('WM_SWITCHER_MODE_EDIT_DOMAIN_WEBMAIL_NAME', 'Webmail');
	define('WM_SWITCHER_MODE_EDIT_DOMAIN_ADDRESS_BOOK_NAME', 'Address Book');

	define('WM_SWITCHER_MODE_EDIT_USERS_GENERAL_NAME', 'General');

	define('WM_INFO_LOGCLEARSUCCESSFUL', 'Log cleared successfully.');

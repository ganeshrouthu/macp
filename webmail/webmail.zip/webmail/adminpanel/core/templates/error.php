<table class="wm_information wm_error_information" style="position:static;" id="info">
	<tbody><tr style="position:relative;z-index:20">
		<td class="wm_shadow" style="width:2px;font-size:1px;"></td>
		<td>
			<div id="info_message" class="wm_info_message">
				<span class="wm_info_image"></span><span class="wm_info_text"><?php
					$this->Data->PrintClearValue('ErrorDesc');
				?></span>
			</div>
			<div class="a">&nbsp;</div>
			<div class="b">&nbsp;</div>
		</td>
		<td class="wm_shadow" style="width:2px;font-size:1px;"></td>
	</tr>
	<tr>
		<td colspan="3" class="wm_shadow" style="height:2px;background:none;">
			<div class="a">&nbsp;</div>
			<div class="b">&nbsp;</div>
		</td>
	</tr>
	<tr style="position:relative;z-index:19">
		<td colspan="3" style="height:2px;">
			<div class="a wm_shadow" style="margin:0px 2px;height:2px; top:-4px; position:relative; border:0px;background:#555;">&nbsp;</div>
		</td>
	</tr>
</tbody></table>